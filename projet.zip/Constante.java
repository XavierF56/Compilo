
public interface Constante{
	//============= Unités lexicales =============
	int VRAI = 99;
	int FAUX = 100;
	int VAR = 103;
	int ENTIER = 104;
	int BOOLEEN = 105;
	int CONST = 106;
	int IDENT = 107;
	int PLUS = 108;
	int MOINS = 109;
	int MULT = 110;
	int DIV = 111;
	int INF = 112;
	int SUP = 113;
	int INFOUEG = 114;
	int SUPOUEG = 115;
	int EGAL = 116;
	int DIFFERENT = 117;
	int ET = 118;
	int OU = 119;
	int ERREUR = -1;
	int NEG = 120;
	int NON = 121;
}
